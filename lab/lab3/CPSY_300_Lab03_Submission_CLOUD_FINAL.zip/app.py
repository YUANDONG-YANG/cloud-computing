"""Uber traffic API for CPSY 300 Lab 03.

The supplied FOIL file is daily/base-level aggregate data (date, trips), while
the lab handout also describes a Date/Time event-level file. This app supports
both schemas and uses `trips` as the weight when the aggregate schema is used.
"""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path

import pandas as pd
from flask import Flask, jsonify, request

try:
    import redis
except ImportError:  # local analysis can run without Redis installed
    redis = None

app = Flask(__name__)
DATA_PATH = os.getenv("DATA_PATH", "Uber-Jan-Feb-FOIL.csv")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
CACHE_TTL = int(os.getenv("CACHE_TTL", "3600"))
redis_client = None


def load_data(path=DATA_PATH):
    df = pd.read_csv(path)
    df = df.dropna().drop_duplicates().copy()
    date_col = "Date/Time" if "Date/Time" in df.columns else "date"
    parsed = [_parse_timestamp(value) for value in df[date_col].tolist()]
    df.loc[:, "Hour"] = [value.hour for value in parsed]
    df.loc[:, "Day"] = [value.date().isoformat() for value in parsed]
    df.loc[:, "DayOfWeek"] = [value.strftime("%A") for value in parsed]
    df.loc[:, "IsWeekend"] = [value.weekday() >= 5 for value in parsed]
    # Event-level data contributes one trip per row; aggregate data contributes
    # the provided trips value per row.
    if "trips" in df.columns:
        df.loc[:, "TripWeight"] = pd.to_numeric(df["trips"], errors="coerce").fillna(1)
    else:
        df.loc[:, "TripWeight"] = 1
    return df, date_col


def _parse_timestamp(value):
    text = str(value).strip()
    for fmt in ("%m/%d/%Y", "%m/%d/%Y %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return datetime.fromisoformat(text.replace("Z", "+00:00"))


df, date_col = load_data()


def get_redis():
    global redis_client
    if redis_client is not None or redis is None:
        return redis_client
    try:
        redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)
        redis_client.ping()
    except Exception:
        redis_client = None
    return redis_client


def cache_key(timestamp):
    return "uber:prediction:" + hashlib.sha256(timestamp.encode()).hexdigest()


def predict(timestamp):
    try:
        parsed = _parse_timestamp(timestamp)
    except (TypeError, ValueError):
        raise ValueError("timestamp must be parseable, e.g. 2015-02-20T00:00:00")
    day = parsed.date().isoformat()
    hour = int(parsed.hour)
    same_hour = df[df["Hour"] == hour]
    same_day = df[df["Day"] == day]
    if same_hour.empty:
        estimate = float(df["TripWeight"].mean())
    else:
        estimate = float(same_hour["TripWeight"].mean())
    return {
        "timestamp": parsed.isoformat(),
        "predicted_trips": round(estimate, 2),
        "observed_trips_for_day": round(float(same_day["TripWeight"].sum()), 2),
        "model": "historical hour-of-day weighted mean",
    }


@app.get("/")
def health():
    return jsonify({"service": "uber-traffic-api", "status": "ok", "rows": len(df)})


@app.get("/predict_traffic")
def predict_traffic():
    timestamp = request.args.get("timestamp", "2015-02-20T00:00:00")
    key = cache_key(timestamp)
    client = get_redis()
    if client:
        cached = client.get(key)
        if cached:
            result = json.loads(cached)
            result["source"] = "cache"
            return jsonify(result)
    try:
        result = predict(timestamp)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    result["source"] = "compute"
    if client:
        client.setex(key, CACHE_TTL, json.dumps(result))
    return jsonify(result)


@app.get("/analysis")
def analysis():
    daily = df.groupby("Day")["TripWeight"].sum().sort_values(ascending=False)
    hourly = df.groupby("Hour")["TripWeight"].sum().sort_values(ascending=False)
    return jsonify({
        "rows_after_cleaning": int(len(df)),
        "date_column_used": date_col,
        "total_trips": int(df["TripWeight"].sum()),
        "busiest_day": {"date": str(daily.index[0]), "trips": int(daily.iloc[0])},
        "peak_hour": {"hour": int(hourly.index[0]), "trips": int(hourly.iloc[0])},
        "daily_top5": [{"day": str(k), "trips": int(v)} for k, v in daily.head(5).items()],
        "hourly": [{"hour": int(k), "trips": int(v)} for k, v in hourly.sort_index().items()],
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
